import json
import boto3
from decimal import Decimal
import logging
import os
from datetime import datetime
import traceback
from bedrock_helper import get_bedrock_prediction
from boto3.dynamodb.types import TypeDeserializer, TypeSerializer
import time

# Konfigurasi logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Allowed origins for CORS
ALLOWED_ORIGINS = [
    'https://ventixcareku.my.id',
    'https://dg52nuiagley4.cloudfront.net',
    'http://localhost:5500'
]

# DynamoDB helpers
serializer = TypeSerializer()
deserializer = TypeDeserializer()

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super(DecimalEncoder, self).default(obj)

def get_cors_headers(event):
    """Get CORS headers based on origin"""
    origin = event.get('headers', {}).get('origin', '')
    if not origin:
        origin = event.get('headers', {}).get('Origin', '')
    
    allowed_origin = origin if origin in ALLOWED_ORIGINS else ALLOWED_ORIGINS[0]
    
    return {
        'Access-Control-Allow-Origin': allowed_origin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,Origin',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
        'Access-Control-Allow-Credentials': 'true'
    }

def log_request(event, context):
    """Log informasi request"""
    request_id = context.aws_request_id
    logger.info(f"Request ID: {request_id}")
    logger.info(f"Event: {json.dumps(event)}")
    logger.info(f"Context: {vars(context)}")
    return request_id

def validate_input(data):
    """Validasi input data"""
    required_fields = ['nama', 'usia', 'beratBadan', 'tinggiBadan', 'tekananDarah', 
                      'gulaDarah', 'riwayatKeluarga', 'olahraga']
    
    # Cek field yang required
    for field in required_fields:
        if field not in data:
            logger.error(f"Missing required field: {field}")
            raise ValueError(f"Field {field} harus diisi")
        
    # Validasi tipe data dan range
    try:
        validations = {
            'usia': (int, 18, 100),
            'beratBadan': (float, 30, 200),
            'tinggiBadan': (float, 140, 220),
            'gulaDarah': (float, 50, 500)
        }
        
        for field, (type_func, min_val, max_val) in validations.items():
            value = type_func(data[field])
            if not min_val <= value <= max_val:
                logger.error(f"Invalid value for {field}: {value}")
                raise ValueError(f"Nilai {field} harus antara {min_val} dan {max_val}")
            
            data[field] = value
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise
    
    return data

def calculate_bmi(weight, height):
    """Hitung BMI"""
    # Convert height from cm to m
    height_m = height / 100
    bmi = weight / (height_m * height_m)
    return round(bmi, 2)

def parse_blood_pressure(bp_string):
    """Parse tekanan darah string ke systolic dan diastolic"""
    try:
        systolic, diastolic = map(int, bp_string.split('/'))
        return systolic, diastolic
    except:
        logger.error(f"Invalid blood pressure format: {bp_string}")
        raise ValueError("Format tekanan darah tidak valid. Gunakan format 'systolic/diastolic' (contoh: 120/80)")

def predict_diabetes_risk(data):
    """
    Predict diabetes risk using both ML model and Bedrock
    """
    # Basic validation
    validate_input(data)
    
    # Get Bedrock prediction
    bedrock_analysis = get_bedrock_prediction(data)
    
    # Combine with existing logic
    prediction = {
        'risk_level': bedrock_analysis['risk_level'],
        'confidence': bedrock_analysis['confidence'],
        'explanation': bedrock_analysis['explanation'],
        'timestamp': datetime.now().isoformat()
    }
    
    return prediction

def convert_to_dynamodb_item(data):
    """Convert Python dict to DynamoDB item format"""
    try:
        # Log raw data
        logger.info(f"Raw data received: {json.dumps(data, default=str)}")
        
        # Helper function untuk konversi ke number
        def safe_number(value, default=0):
            if value is None:
                return default
            try:
                return float(value)
            except (ValueError, TypeError):
                return default

        # Extract and validate predictionId
        prediction_id = data.get('predictionId')
        if isinstance(prediction_id, dict):
            prediction_id = prediction_id.get('S', '')
        prediction_id = str(prediction_id or '')
        logger.info(f"PredictionId after conversion: {prediction_id}, type: {type(prediction_id)}")

        # Format recommendations
        recommendations = data.get('recommendations', [])
        if isinstance(recommendations, str):
            try:
                recommendations = json.loads(recommendations)
            except json.JSONDecodeError:
                recommendations = [recommendations]
        if not isinstance(recommendations, list):
            recommendations = [str(recommendations)]
        recommendations = [str(r) for r in recommendations]
        logger.info(f"Recommendations after formatting: {recommendations}")

        # Create DynamoDB item with explicit type annotations
        item = {
            'predictionId': {'S': prediction_id},  # Ensure string type
            'timestamp': {'N': str(int(safe_number(data.get('timestamp', time.time() * 1000))))},
            'nama': {'S': str(data.get('nama', ''))},
            'jenisKelamin': {'S': str(data.get('jenisKelamin', ''))},
            'usia': {'N': str(int(safe_number(data.get('usia', 0))))},
            'beratBadan': {'N': str(safe_number(data.get('beratBadan', 0)))},
            'tinggiBadan': {'N': str(safe_number(data.get('tinggiBadan', 0)))},
            'tekananDarah': {'N': str(safe_number(data.get('tekananDarah', 0)))},
            'gulaDarah': {'N': str(safe_number(data.get('gulaDarah', 0)))},
            'kolesterol': {'N': str(safe_number(data.get('kolesterol', 0)))},
            'riwayatKeluarga': {'S': str(data.get('riwayatKeluarga', 'tidak'))},
            'aktivitasFisik': {'S': str(data.get('aktivitasFisik', 'rendah'))},
            'pola_makan': {'S': str(data.get('pola_makan', 'tidak_sehat'))},
            'stres': {'S': str(data.get('stres', 'rendah'))},
            'merokok': {'S': str(data.get('merokok', 'tidak'))},
            'alkohol': {'S': str(data.get('alkohol', 'tidak'))},
            'bmi': {'N': str(safe_number(data.get('bmi', 0)))},
            'riskLevel': {'S': str(data.get('riskLevel', 'rendah'))},
            'recommendations': {'S': json.dumps(recommendations)}
        }

        # Log the final item for debugging
        logger.info(f"Final DynamoDB item: {json.dumps(item, default=str)}")
        
        return item
        
    except Exception as e:
        logger.error(f"Error converting data to DynamoDB format: {str(e)}")
        logger.error(f"Data: {json.dumps(data, default=str)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        raise

def lambda_handler(event, context):
    """Main handler function"""
    try:
        # Log request details
        request_id = log_request(event, context)
        logger.info(f"Processing request {request_id}")
        
        # Get CORS headers
        cors_headers = get_cors_headers(event)
        
        # Parse request
        if 'body' not in event:
            raise ValueError("Missing request body")
            
        try:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
            logger.info(f"Received body: {json.dumps(body, default=str)}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse request body: {str(e)}")
            logger.error(f"Raw body: {event['body']}")
            raise ValueError("Invalid JSON in request body")
        
        # Get path and method
        path = event.get('path', '').rstrip('/')
        http_method = event.get('httpMethod', '')
        
        # Log request details
        logger.info(f"Path: {path}, Method: {http_method}")
        
        if path == '/predict' and http_method == 'POST':
            # Handle prediction request
            if not body:
                raise ValueError("Empty request body")
                
            # Validate input
            validate_input(body)
            
            # Make prediction
            result = predict_diabetes_risk(body)
            
            return {
                'statusCode': 200,
                'headers': cors_headers,
                'body': json.dumps(result, cls=DecimalEncoder)
            }
            
        elif path == '/history' and http_method == 'POST':
            # Handle save to history
            try:
                # Convert data for DynamoDB
                item = convert_to_dynamodb_item(body)
                logger.info(f"Converted item for DynamoDB: {json.dumps(item, default=str)}")
                
                # Get DynamoDB table
                dynamodb = boto3.client('dynamodb')
                table_name = os.environ['TABLE_NAME']
                
                # Save to DynamoDB
                logger.info(f"Saving to table {table_name}")
                dynamodb.put_item(
                    TableName=table_name,
                    Item=item
                )
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({'message': 'Data saved successfully'})
                }
                
            except Exception as e:
                logger.error(f"Error saving to database: {str(e)}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                return {
                    'statusCode': 500,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'error': 'Error saving to database',
                        'details': str(e)
                    })
                }
                
        elif path == '/history' and http_method == 'GET':
            # Handle get history
            try:
                # Get DynamoDB table
                dynamodb = boto3.client('dynamodb')
                table_name = os.environ['TABLE_NAME']
                
                # Scan table
                response = dynamodb.scan(TableName=table_name)
                
                # Convert DynamoDB items to regular JSON
                items = []
                for item in response.get('Items', []):
                    converted_item = {}
                    for key, value in item.items():
                        # Get the first (and only) key in the value dict
                        type_key = list(value.keys())[0]
                        converted_item[key] = value[type_key]
                    items.append(converted_item)
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps(items, cls=DecimalEncoder)
                }
                
            except Exception as e:
                logger.error(f"Error getting history: {str(e)}")
                return {
                    'statusCode': 500,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'error': 'Error getting history',
                        'details': str(e)
                    })
                }
        else:
            return {
                'statusCode': 404,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Not Found'})
            }
            
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return {
            'statusCode': 400,
            'headers': cors_headers,
            'body': json.dumps({
                'error': 'Validation Error',
                'details': str(e)
            })
        }
        
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({
                'error': 'Internal Server Error',
                'details': str(e)
            })
        }
