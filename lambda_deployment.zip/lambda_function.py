import json
import boto3
from decimal import Decimal
import logging
import os
from datetime import datetime
import traceback
from bedrock_helper import get_bedrock_prediction
from boto3.dynamodb.types import TypeDeserializer, TypeSerializer
import time

# Konfigurasi logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Allowed origins for CORS
ALLOWED_ORIGINS = [
    'https://ventixcareku.my.id',
    'https://dg52nuiagley4.cloudfront.net',
    'http://localhost:5500'
]

# DynamoDB helpers
serializer = TypeSerializer()
deserializer = TypeDeserializer()

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super(DecimalEncoder, self).default(obj)

def get_cors_headers(event):
    """Get CORS headers based on origin"""
    origin = event.get('headers', {}).get('origin', '')
    if not origin:
        origin = event.get('headers', {}).get('Origin', '')
    
    allowed_origin = origin if origin in ALLOWED_ORIGINS else ALLOWED_ORIGINS[0]
    
    return {
        'Access-Control-Allow-Origin': allowed_origin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,Origin',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
        'Access-Control-Allow-Credentials': 'true'
    }

def log_request(event, context):
    """Log informasi request"""
    request_id = context.aws_request_id
    logger.info(f"Request ID: {request_id}")
    logger.info(f"Event: {json.dumps(event)}")
    logger.info(f"Context: {vars(context)}")
    return request_id

def validate_input(data):
    """Validasi input data"""
    required_fields = ['nama', 'usia', 'beratBadan', 'tinggiBadan', 'tekananDarah', 
                      'gulaDarah', 'riwayatKeluarga', 'olahraga']
    
    # Cek field yang required
    for field in required_fields:
        if field not in data:
            logger.error(f"Missing required field: {field}")
            raise ValueError(f"Field {field} harus diisi")
        
    # Validasi tipe data dan range
    try:
        validations = {
            'usia': (int, 18, 100),
            'beratBadan': (float, 30, 200),
            'tinggiBadan': (float, 140, 220),
            'gulaDarah': (float, 50, 500)
        }
        
        for field, (type_func, min_val, max_val) in validations.items():
            value = type_func(data[field])
            if not min_val <= value <= max_val:
                logger.error(f"Invalid value for {field}: {value}")
                raise ValueError(f"Nilai {field} harus antara {min_val} dan {max_val}")
            
            data[field] = value
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise
    
    return data

def calculate_bmi(weight, height):
    """Hitung BMI"""
    # Convert height from cm to m
    height_m = height / 100
    bmi = weight / (height_m * height_m)
    return round(bmi, 2)

def parse_blood_pressure(bp_string):
    """Parse tekanan darah string ke systolic dan diastolic"""
    try:
        systolic, diastolic = map(int, bp_string.split('/'))
        return systolic, diastolic
    except:
        logger.error(f"Invalid blood pressure format: {bp_string}")
        raise ValueError("Format tekanan darah tidak valid. Gunakan format 'systolic/diastolic' (contoh: 120/80)")

def predict_diabetes_risk(data):
    """
    Predict diabetes risk using both ML model and Bedrock
    """
    # Basic validation
    validate_input(data)
    
    # Get Bedrock prediction
    bedrock_analysis = get_bedrock_prediction(data)
    
    # Combine with existing logic
    prediction = {
        'risk_level': bedrock_analysis['risk_level'],
        'confidence': bedrock_analysis['confidence'],
        'explanation': bedrock_analysis['explanation'],
        'timestamp': datetime.now().isoformat()
    }
    
    return prediction

def convert_to_dynamodb_item(data):
    """Convert Python dict to DynamoDB item format"""
    try:
        # Helper function untuk mengkonversi ke Decimal
        def to_decimal(value):
            if value is None or value == "":
                return "0"
            try:
                # Hapus spasi dan karakter non-numerik kecuali titik
                cleaned = ''.join(c for c in str(value) if c.isdigit() or c == '.')
                if not cleaned:
                    return "0"
                # Pastikan hanya ada satu titik desimal
                parts = cleaned.split('.')
                if len(parts) > 2:
                    cleaned = parts[0] + '.' + parts[1]
                return str(Decimal(cleaned))
            except:
                return "0"

        # Log raw data
        logger.info(f"Raw data received: {json.dumps(data, default=str)}")

        # Pastikan predictionId adalah string
        prediction_id = str(data.get('predictionId', ''))
        if not prediction_id:
            prediction_id = f"pred_{int(time.time() * 1000)}"

        # Konversi semua field numerik ke Decimal
        item = {
            'predictionId': {'S': prediction_id},
            'timestamp': {'N': to_decimal(data.get('timestamp', time.time() * 1000))},
            'nama': {'S': str(data.get('nama', ''))},
            'jenisKelamin': {'S': str(data.get('jenisKelamin', 'Tidak Disebutkan'))},
            'usia': {'N': to_decimal(data.get('usia', 0))},
            'beratBadan': {'N': to_decimal(data.get('beratBadan', 0))},
            'tinggiBadan': {'N': to_decimal(data.get('tinggiBadan', 0))},
            'tekananDarah': {'S': str(data.get('tekananDarah', '120/80'))},
            'gulaDarah': {'N': to_decimal(data.get('gulaDarah', 0))},
            'riwayatKeluarga': {'BOOL': bool(data.get('riwayatKeluarga', False))},
            'olahraga': {'S': str(data.get('olahraga', 'Jarang'))},
            'riskLevel': {'S': str(data.get('riskLevel', 'Medium'))},
            'bmi': {'N': to_decimal(data.get('bmi', 0))},
            'isoTimestamp': {'S': str(data.get('isoTimestamp', datetime.now().isoformat()))}
        }

        # Log converted item
        logger.info(f"Converted item for DynamoDB: {json.dumps(item, default=str)}")

        # Tambahkan recommendations jika ada
        if 'recommendations' in data:
            item['recommendations'] = {'S': json.dumps(data['recommendations'])}

        # Tambahkan status kehamilan jika perempuan
        if data.get('jenisKelamin') == 'Perempuan':
            item['hamil'] = {'S': str(data.get('hamil', 'Tidak'))}

        return item
    except Exception as e:
        logger.error(f"Error converting to DynamoDB item: {str(e)}")
        logger.error(f"Data received: {json.dumps(data, default=str)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        raise Exception(f"Error converting to DynamoDB item: {str(e)}")

def lambda_handler(event, context):
    """Main handler function"""
    try:
        # Log request
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Handle CORS preflight request
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': get_cors_headers(event),
                'body': json.dumps({})
            }
        
        # Get DynamoDB table
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ['TABLE_NAME'])
        
        if event['httpMethod'] == 'POST' and event['resource'] == '/predict':
            # Log request
            request_id = log_request(event, context)
            
            # Parse request body
            try:
                body = json.loads(event['body'])
                logger.info(f"Received body: {json.dumps(body)}")
            except Exception as e:
                logger.error(f"Error parsing request body: {str(e)}")
                return {
                    'statusCode': 400,
                    'headers': get_cors_headers(event),
                    'body': json.dumps({
                        'error': 'Invalid request body',
                        'details': str(e)
                    })
                }
            
            # Validate input
            data = validate_input(body)
            
            # Calculate prediction
            prediction = predict_diabetes_risk(data)
            
            # Prepare item for DynamoDB
            timestamp = datetime.now().isoformat()
            item = {
                'predictionId': request_id,
                'timestamp': timestamp,
                **{k: (Decimal(str(v)) if isinstance(v, (int, float)) else v) for k, v in data.items()},
                **{k: (Decimal(str(v)) if isinstance(v, (int, float)) else v) for k, v in prediction.items()}
            }
            
            # Save to DynamoDB
            try:
                table.put_item(Item=item)
            except Exception as e:
                logger.error(f"Error saving to DynamoDB: {str(e)}")
                return {
                    'statusCode': 500,
                    'headers': get_cors_headers(event),
                    'body': json.dumps({
                        'error': 'Error saving to database',
                        'details': str(e)
                    })
                }
            
            return {
                'statusCode': 200,
                'headers': get_cors_headers(event),
                'body': json.dumps({
                    'predictionId': request_id,
                    'timestamp': timestamp,
                    **data,
                    **prediction
                }, cls=DecimalEncoder)
            }
            
        elif event['httpMethod'] == 'POST' and event['resource'] == '/history':
            # Parse request body
            try:
                body = json.loads(event['body'])
                logger.info(f"Received body: {json.dumps(body)}")
                logger.info(f"timestamp type: {type(body.get('timestamp'))}")
                logger.info(f"timestamp value: {body.get('timestamp')}")
            except Exception as e:
                logger.error(f"Error parsing request body: {str(e)}")
                return {
                    'statusCode': 400,
                    'headers': get_cors_headers(event),
                    'body': json.dumps({
                        'error': 'Invalid request body',
                        'details': str(e)
                    })
                }
            
            # Validate required fields
            required_fields = ['predictionId', 'timestamp', 'usia']
            missing_fields = [field for field in required_fields if not body.get(field)]
            if missing_fields:
                return {
                    'statusCode': 400,
                    'headers': get_cors_headers(event),
                    'body': json.dumps({
                        'error': 'Missing required fields',
                        'fields': missing_fields
                    })
                }
            
            try:
                # Convert data to DynamoDB format
                dynamodb_item = convert_to_dynamodb_item(body)
                logger.info(f"DynamoDB item: {json.dumps(dynamodb_item)}")

                # Save to DynamoDB
                table.put_item(Item=dynamodb_item)
                
            except Exception as e:
                logger.error(f"Error processing data: {str(e)}")
                logger.error(f"Body content: {json.dumps(body)}")
                logger.error(traceback.format_exc())
                return {
                    'statusCode': 500,
                    'headers': get_cors_headers(event),
                    'body': json.dumps({
                        'error': 'Error saving to database',
                        'details': str(e)
                    })
                }
            
            return {
                'statusCode': 200,
                'headers': get_cors_headers(event),
                'body': json.dumps({
                    'message': 'Data saved successfully',
                    'id': body['predictionId']
                }, cls=DecimalEncoder)
            }
            
        elif event['httpMethod'] == 'GET' and event['resource'] == '/history':
            # Get all items from DynamoDB
            try:
                response = table.scan()
                items = response.get('Items', [])
            except Exception as e:
                logger.error(f"Error reading from DynamoDB: {str(e)}")
                return {
                    'statusCode': 500,
                    'headers': get_cors_headers(event),
                    'body': json.dumps({
                        'error': 'Error reading from database',
                        'details': str(e)
                    })
                }
            
            return {
                'statusCode': 200,
                'headers': get_cors_headers(event),
                'body': json.dumps({
                    'items': items
                }, cls=DecimalEncoder)
            }
            
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': get_cors_headers(event),
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }
