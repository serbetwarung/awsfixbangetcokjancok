import json
import boto3
import logging
from datetime import datetime
import time
from decimal import Decimal

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('diabetes-predictions')

# Custom JSON encoder to handle Decimal
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def parse_blood_pressure(bp_string):
    try:
        systolic, diastolic = bp_string.split('/')
        return Decimal(str(systolic))
    except Exception as e:
        logger.error(f"Error parsing blood pressure: {str(e)}")
        return Decimal('0')

def calculate_risk(data):
    logger.info(f"Calculating risk for data: {data}")
    points = 0
    
    try:
        # Blood Sugar Risk
        blood_sugar = Decimal(str(data.get('gulaDarah', '0')))
        if blood_sugar >= Decimal('126'):
            points += 3
        elif blood_sugar >= Decimal('100'):
            points += 2
        
        # Blood Pressure Risk
        blood_pressure = parse_blood_pressure(data.get('tekananDarah', '0/0'))
        if blood_pressure >= Decimal('140'):
            points += 3
        elif blood_pressure >= Decimal('130'):
            points += 2
        
        # BMI Risk
        bmi = Decimal(str(data.get('bmi', '0')))
        if bmi >= Decimal('30'):
            points += 3
        elif bmi >= Decimal('25'):
            points += 2
        
        # Age Risk
        age = int(data.get('usia', 0))
        if age >= 45:
            points += 3
        elif age >= 35:
            points += 2

        logger.info(f"Calculated points: {points}")

        # Determine risk level
        if points >= 8:
            return "Tinggi"
        elif points >= 5:
            return "Sedang"
        else:
            return "Rendah"
    except Exception as e:
        logger.error(f"Error in calculate_risk: {str(e)}")
        raise

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    # CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    }
    
    # Handle OPTIONS request for CORS
    if event.get('httpMethod') == 'OPTIONS':
        logger.info("Handling OPTIONS request")
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({'message': 'CORS enabled'})
        }
        
    try:
        # Parse input data
        raw_body = event.get('body', '{}')
        logger.info(f"Raw body: {raw_body}")
        
        body = json.loads(raw_body)
        logger.info(f"Parsed body: {body}")
        
        # Validate required fields
        required_fields = ['nama', 'jenisKelamin', 'usia', 'tinggiBadan', 'beratBadan', 'gulaDarah', 'tekananDarah', 'olahraga', 'riwayatKeluarga']
        missing_fields = [field for field in required_fields if field not in body]
        if missing_fields:
            raise ValueError(f"Data tidak lengkap. Field yang kurang: {', '.join(missing_fields)}")
            
        # Convert numeric fields to Decimal for DynamoDB
        try:
            body['usia'] = int(body['usia'])
            body['tinggiBadan'] = Decimal(str(body['tinggiBadan']))
            body['beratBadan'] = Decimal(str(body['beratBadan']))
            body['gulaDarah'] = Decimal(str(body['gulaDarah']))
            
            # Calculate BMI if not provided
            if 'bmi' not in body:
                height_m = body['tinggiBadan'] / Decimal('100')
                body['bmi'] = body['beratBadan'] / (height_m * height_m)
                
        except (ValueError, TypeError) as e:
            raise ValueError(f"Format data tidak valid: {str(e)}")
        
        # Calculate risk
        risk_level = calculate_risk(body)
        logger.info(f"Calculated risk level: {risk_level}")
        
        # Generate recommendations
        recommendations = get_recommendations(risk_level, body)
        logger.info(f"Generated recommendations: {recommendations}")
        
        # Save to DynamoDB
        timestamp = int(time.time())
        item = {
            'predictionId': f"{timestamp}-{body.get('nama', 'anonymous')}",
            'timestamp': timestamp,
            'userData': body,
            'riskLevel': risk_level,
            'recommendations': recommendations
        }
        
        logger.info(f"Saving to DynamoDB: {item}")
        table.put_item(Item=json.loads(json.dumps(item, cls=DecimalEncoder), parse_float=Decimal))
        
        response_body = {
            'riskLevel': risk_level,
            'recommendations': recommendations
        }
        logger.info(f"Sending response: {response_body}")
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(response_body, cls=DecimalEncoder)
        }
        
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({
                'error': str(e),
                'message': 'Terjadi kesalahan validasi data'
            })
        }
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': str(e),
                'message': 'Terjadi kesalahan internal server'
            })
        }

def calculateBMI(weight, height):
    """Calculate BMI from weight (kg) and height (cm)"""
    height_m = Decimal(str(height)) / Decimal('100')  # convert cm to m
    return Decimal(str(weight)) / (height_m * height_m)

def get_recommendations(risk_level, data):
    logger.info(f"Getting recommendations for risk level: {risk_level}")
    recommendations = []
    
    if risk_level == "Tinggi":
        recommendations = [
            "Segera konsultasi dengan dokter",
            "Pantau gula darah secara teratur",
            "Kurangi konsumsi karbohidrat dan gula",
            "Lakukan olahraga ringan 30 menit setiap hari"
        ]
    elif risk_level == "Sedang":
        recommendations = [
            "Konsultasi dengan dokter untuk pemeriksaan lebih lanjut",
            "Mulai program diet sehat",
            "Tingkatkan aktivitas fisik"
        ]
    else:
        recommendations = [
            "Pertahankan pola hidup sehat",
            "Lakukan pemeriksaan rutin setiap tahun",
            "Jaga berat badan ideal"
        ]
    
    return recommendations
