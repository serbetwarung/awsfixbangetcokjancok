import json
import boto3
from decimal import Decimal
import logging
import os
from datetime import datetime
import traceback
from bedrock_helper import get_bedrock_prediction

# Konfigurasi logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Allowed origins for CORS
ALLOWED_ORIGINS = [
    'https://ventixcareku.my.id',
    'https://dg52nuiagley4.cloudfront.net',
    'http://localhost:5500'
]

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super(DecimalEncoder, self).default(obj)

def get_cors_headers(event):
    """Get CORS headers based on origin"""
    origin = event.get('headers', {}).get('origin', '')
    allowed_origin = origin if origin in ALLOWED_ORIGINS else ALLOWED_ORIGINS[0]
    
    return {
        'Access-Control-Allow-Origin': allowed_origin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
        'Access-Control-Allow-Credentials': 'true'
    }

def log_request(event, context):
    """Log informasi request"""
    request_id = context.aws_request_id
    logger.info(f"Request ID: {request_id}")
    logger.info(f"Event: {json.dumps(event, cls=DecimalEncoder)}")
    logger.info(f"Context: {vars(context)}")
    return request_id

def validate_input(data):
    """Validasi input data"""
    required_fields = ['nama', 'usia', 'beratBadan', 'tinggiBadan', 'tekananDarah', 
                      'gulaDarah', 'riwayatKeluarga', 'olahraga']
    
    # Cek field yang required
    for field in required_fields:
        if field not in data:
            logger.error(f"Missing required field: {field}")
            raise ValueError(f"Field {field} harus diisi")
        
    # Validasi tipe data dan range
    try:
        validations = {
            'usia': (int, 18, 100),
            'beratBadan': (float, 30, 200),
            'tinggiBadan': (float, 140, 220),
            'gulaDarah': (float, 50, 500)
        }
        
        for field, (type_func, min_val, max_val) in validations.items():
            value = type_func(data[field])
            if not min_val <= value <= max_val:
                logger.error(f"Invalid value for {field}: {value}")
                raise ValueError(f"Nilai {field} harus antara {min_val} dan {max_val}")
            
            data[field] = value
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise
    
    return data

def calculate_bmi(weight, height):
    """Hitung BMI"""
    # Convert height from cm to m
    height_m = height / 100
    bmi = weight / (height_m * height_m)
    return round(bmi, 2)

def parse_blood_pressure(bp_string):
    """Parse tekanan darah string ke systolic dan diastolic"""
    try:
        systolic, diastolic = map(int, bp_string.split('/'))
        return systolic, diastolic
    except:
        logger.error(f"Invalid blood pressure format: {bp_string}")
        raise ValueError("Format tekanan darah tidak valid. Gunakan format 'systolic/diastolic' (contoh: 120/80)")

def predict_diabetes_risk(data):
    """
    Predict diabetes risk using both ML model and Bedrock
    """
    # Basic validation
    validate_input(data)
    
    # Get Bedrock prediction
    bedrock_analysis = get_bedrock_prediction(data)
    
    # Combine with existing logic
    prediction = {
        'risk_level': bedrock_analysis['risk_level'],
        'confidence': bedrock_analysis['confidence'],
        'explanation': bedrock_analysis['explanation'],
        'timestamp': datetime.now().isoformat()
    }
    
    return prediction

def lambda_handler(event, context):
    """Main handler function"""
    try:
        # Handle OPTIONS request for CORS
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': get_cors_headers(event),
                'body': json.dumps({'message': 'CORS preflight successful'})
            }
        
        # Log request
        request_id = log_request(event, context)
        
        # Get DynamoDB table
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ['TABLE_NAME'])
        
        # Parse request body
        body = json.loads(event['body']) if event.get('body') else {}
        
        # Validate input
        data = validate_input(body)
        
        # Calculate prediction
        prediction = predict_diabetes_risk(data)
        
        # Prepare item for DynamoDB
        timestamp = datetime.now().isoformat()
        item = {
            'predictionId': request_id,
            'timestamp': timestamp,
            **{k: (Decimal(str(v)) if isinstance(v, (int, float)) else v) for k, v in data.items()},
            **{k: (Decimal(str(v)) if isinstance(v, (int, float)) else v) for k, v in prediction.items()}
        }
        
        # Save to DynamoDB
        table.put_item(Item=item)
        
        # Prepare response
        response = {
            'predictionId': request_id,
            'timestamp': timestamp,
            **data,
            **prediction
        }
        
        return {
            'statusCode': 200,
            'headers': get_cors_headers(event),
            'body': json.dumps(response, cls=DecimalEncoder)
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}\nTraceback: {traceback.format_exc()}")
        return {
            'statusCode': 400 if isinstance(e, ValueError) else 500,
            'headers': get_cors_headers(event),
            'body': json.dumps({
                'error': str(e),
                'type': type(e).__name__
            })
        }
