import json
import boto3
import os
from datetime import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

bedrock = boto3.client('bedrock-runtime')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['CHAT_HISTORY_TABLE'])

def get_chat_history(user_id, limit=5):
    response = table.query(
        KeyConditionExpression='user_id = :uid',
        ExpressionAttributeValues={':uid': user_id},
        Limit=limit,
        ScanIndexForward=False  # Get most recent messages first
    )
    return response.get('Items', [])

def store_message(user_id, role, content):
    timestamp = datetime.utcnow().isoformat()
    table.put_item(Item={
        'user_id': user_id,
        'timestamp': timestamp,
        'role': role,
        'content': content
    })

def create_prompt(user_message, chat_history):
    messages = []
    
    # Add system message
    messages.append({
        "role": "system",
        "content": """Anda adalah asisten kesehatan yang membantu memberikan informasi tentang diabetes.
        Jawaban Anda harus:
        1. Akurat dan berdasarkan pengetahuan medis
        2. Empatik dan suportif
        3. Jelas dan mudah dipahami
        4. Singkat namun informatif (maksimal 3 kalimat)
        5. Dalam Bahasa Indonesia
        
        Ingat untuk:
        - Jangan memberikan diagnosis medis
        - Anjurkan untuk berkonsultasi dengan profesional kesehatan
        - Fokus pada edukasi dan dukungan umum"""
    })
    
    # Add chat history
    for item in reversed(chat_history):
        messages.append({
            "role": "user" if item['role'] == 'user' else "assistant",
            "content": item['content']
        })
    
    # Add current message
    messages.append({
        "role": "user",
        "content": user_message
    })
    
    return messages

def lambda_handler(event, context):
    try:
        logger.info("Event received: %s", json.dumps(event))
        
        # Extract user message and ID from event
        body = json.loads(event['body'])
        user_message = body['message']
        user_id = event['requestContext']['identity']['sourceIp']  # Using IP as user ID for demo
        
        logger.info("Processing message from user %s: %s", user_id, user_message)
        
        # Get chat history
        chat_history = get_chat_history(user_id)
        
        # Store user message
        store_message(user_id, 'user', user_message)
        
        # Create messages array
        messages = create_prompt(user_message, chat_history)
        
        # Call Bedrock with Mistral model
        response = bedrock.invoke_model(
            modelId='mistral.mistral-small-2402-v1:0',
            body=json.dumps({
                "messages": messages,
                "max_tokens": 300,
                "temperature": 0.7,
                "top_p": 0.9
            })
        )
        
        # Parse response
        response_body = json.loads(response['body'].read())
        logger.info("Bedrock response: %s", json.dumps(response_body))
        
        bot_message = response_body['choices'][0]['message']['content']
        
        # Store bot response
        store_message(user_id, 'assistant', bot_message)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps({
                'message': bot_message
            })
        }
    except Exception as e:
        logger.error("Error occurred: %s", str(e), exc_info=True)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps({
                'message': 'Maaf, terjadi kesalahan. Silakan coba lagi nanti.'
            })
        }
