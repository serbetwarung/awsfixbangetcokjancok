const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'diabetes-predictions';

// Helper untuk generate UUID
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Helper untuk CORS headers
const corsHeaders = {
    'Access-Control-Allow-Origin': 'https://ventixcareku.my.id',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'OPTIONS,POST',
    'Content-Type': 'application/json'
};

// Helper untuk validasi numerik dengan range
function validateNumericRange(value, min, max, fieldName) {
    const num = parseFloat(value);
    if (isNaN(num)) {
        throw new Error(`${fieldName} harus berupa angka`);
    }
    if (num < min || num > max) {
        throw new Error(`${fieldName} harus antara ${min} dan ${max}`);
    }
    return num;
}

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Handle OPTIONS request (CORS preflight)
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 204,
            headers: corsHeaders,
            body: ''
        };
    }

    try {
        if (!event.body) {
            throw new Error('Missing request body');
        }

        const data = JSON.parse(event.body);
        
        // Validate required fields
        const requiredFields = ['nama', 'jenisKelamin', 'usia', 'beratBadan', 'tinggiBadan', 'tekananDarah', 'gulaDarah', 'riwayatKeluarga'];
        for (const field of requiredFields) {
            if (!data[field] && data[field] !== 0) {
                throw new Error(`Missing required field: ${field}`);
            }
        }

        // Validate and normalize data types
        try {
            data.usia = validateNumericRange(data.usia, 1, 120, 'Usia');
            data.beratBadan = validateNumericRange(data.beratBadan, 20, 300, 'Berat badan');
            data.tinggiBadan = validateNumericRange(data.tinggiBadan, 50, 250, 'Tinggi badan');
            data.gulaDarah = validateNumericRange(data.gulaDarah, 50, 500, 'Gula darah');
            
            // Validate blood pressure format and range
            if (!data.tekananDarah.match(/^\d+\/\d+$/)) {
                throw new Error('Format tekanan darah harus "120/80"');
            }
            const [systolic, diastolic] = data.tekananDarah.split('/').map(Number);
            if (systolic < 70 || systolic > 250 || diastolic < 40 || diastolic > 150) {
                throw new Error('Nilai tekanan darah tidak valid');
            }
            
            // Normalize riwayatKeluarga to boolean
            data.riwayatKeluarga = data.riwayatKeluarga === true || data.riwayatKeluarga === 'Ya';
            
            // Validate gender
            if (!['Laki-laki', 'Perempuan'].includes(data.jenisKelamin)) {
                throw new Error('Jenis kelamin harus "Laki-laki" atau "Perempuan"');
            }
            
        } catch (validationError) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ 
                    error: 'Validation error',
                    details: validationError.message
                })
            };
        }

        // Calculate BMI with 2 decimal precision
        const heightInMeters = data.tinggiBadan / 100;
        const bmi = parseFloat((data.beratBadan / (heightInMeters * heightInMeters)).toFixed(2));

        // Determine risk level based on factors
        let riskLevel = 'Rendah';
        let riskPoints = 0;

        // BMI check
        if (bmi >= 30) riskPoints += 2;
        else if (bmi >= 25) riskPoints += 1;

        // Age check
        if (data.usia >= 45) riskPoints += 2;
        else if (data.usia >= 35) riskPoints += 1;

        // Blood pressure check
        const [systolic, diastolic] = data.tekananDarah.split('/').map(Number);
        if (systolic >= 140 || diastolic >= 90) riskPoints += 2;
        else if (systolic >= 130 || diastolic >= 85) riskPoints += 1;

        // Blood sugar check
        if (data.gulaDarah >= 126) riskPoints += 2;
        else if (data.gulaDarah >= 100) riskPoints += 1;

        // Family history
        if (data.riwayatKeluarga) riskPoints += 2;

        // Set risk level based on points
        if (riskPoints >= 6) riskLevel = 'Sangat Tinggi';
        else if (riskPoints >= 4) riskLevel = 'Tinggi';
        else if (riskPoints >= 2) riskLevel = 'Sedang';

        // Generate recommendations
        const recommendations = [];
        
        if (bmi >= 25) {
            recommendations.push('Kurangi berat badan melalui diet sehat dan olahraga teratur');
        }
        
        if (systolic >= 130 || diastolic >= 85) {
            recommendations.push('Kurangi konsumsi garam');
            recommendations.push('Kelola stres dengan baik');
        }
        
        if (data.gulaDarah >= 100) {
            recommendations.push('Lakukan pemeriksaan gula darah rutin');
            recommendations.push('Jaga pola makan sehat');
        }

        // Add general recommendations based on risk level
        if (riskLevel === 'Sangat Tinggi' || riskLevel === 'Tinggi') {
            recommendations.push('Segera konsultasi dengan dokter');
            recommendations.push('Lakukan pemeriksaan kesehatan menyeluruh');
        } else if (riskLevel === 'Sedang') {
            recommendations.push('Mulai menerapkan pola hidup sehat');
            recommendations.push('Pertimbangkan untuk melakukan pemeriksaan kesehatan');
        } else {
            recommendations.push('Pertahankan pola hidup sehat');
            recommendations.push('Lakukan pemeriksaan kesehatan rutin setahun sekali');
        }

        // Lifestyle factors with proper data types
        const defaultLifestyleFactors = {
            merokok: false,
            alkohol: false,
            aktivitasFisik: 'rendah',
            stres: 'rendah',
            pola_makan: 'sehat',
            kolesterol: 0
        };

        // Get current timestamp
        const timestamp = Date.now();
        const predictionId = generateUUID();

        // Prepare item for DynamoDB with consistent data types
        const item = {
            predictionId,
            timestamp,
            nama: data.nama.trim(),
            jenisKelamin: data.jenisKelamin,
            usia: data.usia,
            beratBadan: data.beratBadan,
            tinggiBadan: data.tinggiBadan,
            tekananDarah: data.tekananDarah,
            gulaDarah: data.gulaDarah,
            riwayatKeluarga: data.riwayatKeluarga,
            bmi,
            riskLevel,
            recommendations,
            ...defaultLifestyleFactors
        };

        // Save to DynamoDB
        await dynamoDB.put({
            TableName: TABLE_NAME,
            Item: item
        }).promise();

        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                message: 'Data prediksi berhasil disimpan',
                data: item
            })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: error.statusCode || 500,
            headers: corsHeaders,
            body: JSON.stringify({
                error: 'Gagal menyimpan prediksi',
                details: error.message
            })
        };
    }
};
